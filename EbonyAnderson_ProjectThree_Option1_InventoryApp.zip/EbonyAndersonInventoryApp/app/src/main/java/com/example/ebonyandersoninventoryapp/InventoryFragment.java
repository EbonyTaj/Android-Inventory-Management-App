package com.example.ebonyandersoninventoryapp;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import android.Manifest;
import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import java.util.ArrayList;
import java.util.UUID;
import android.content.pm.PackageManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.provider.Settings;
import android.widget.CheckBox;
import android.database.Cursor;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import androidx.appcompat.app.AlertDialog;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;


public class InventoryFragment extends Fragment {
    private static final String SMS_PREFERENCES = "sms_preferences";
    private static final String SMS_ENABLED = "sms_enabled";
    private static final String SMS_PHONE = "sms_phone";
    private static final int LOW_STOCK_THRESHOLD = 5;

    private final ActivityResultLauncher<String> smsPermissionLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.RequestPermission(),
                    isGranted -> {
                        // Permission grants affect future stock changes; do not send old alerts.
                        if (!isGranted) {
                            getSmsPreferences().edit().putBoolean(SMS_ENABLED, false).apply();
                        }
                        Toast.makeText(requireContext(), isGranted
                                ? R.string.sms_permission_granted
                                : R.string.sms_permission_denied, Toast.LENGTH_LONG).show();
                    }
            );


    public static InventoryFragment newInstance() {
        return new InventoryFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_inventory, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view,
                              @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        view.findViewById(R.id.buttonSmsSettings)
                .setOnClickListener(v -> showSmsSettingsDialog());

        EditText itemNameEditText =
                requireView().findViewById(R.id.editItemName);

        EditText quantityEditText =
                requireView().findViewById(R.id.editQuantity);

        Button addItemButton =
                requireView().findViewById(R.id.buttonAddItem);

        // Recheck both fields after every typed or pasted change.
        TextWatcher addItemValidationWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence text, int start, int count, int after) { }

            @Override
            public void onTextChanged(CharSequence text, int start, int before, int count) { }

            @Override
            public void afterTextChanged(Editable text) {
                addItemButton.setEnabled(validateAddItemInputs(
                        itemNameEditText, quantityEditText, true));
            }
        };
        itemNameEditText.addTextChangedListener(addItemValidationWatcher);
        quantityEditText.addTextChangedListener(addItemValidationWatcher);
        // Start with Add disabled, without showing errors on an untouched form.
        addItemButton.setEnabled(validateAddItemInputs(
                itemNameEditText, quantityEditText, false));

        DatabaseHelper databaseHelper =
                new DatabaseHelper(requireContext());

        LinearLayout inventoryContainer =
                requireView().findViewById(R.id.inventoryContainer);

        TextView textEmptyInventory =
                requireView().findViewById(R.id.textEmptyInventory);

        // Load inventory items already stored in the database.
        Cursor cursor = databaseHelper.getAllInventoryItems();

        if (cursor.getCount() > 0) {

            textEmptyInventory.setVisibility(View.GONE);

            while (cursor.moveToNext()) {

                int itemId = cursor.getInt(
                        cursor.getColumnIndexOrThrow("id"));

                String itemName = cursor.getString(
                        cursor.getColumnIndexOrThrow("item_name"));

                int quantity = cursor.getInt(
                        cursor.getColumnIndexOrThrow("quantity"));

                LinearLayout rowLayout =
                        new LinearLayout(requireContext());

                rowLayout.setOrientation(LinearLayout.HORIZONTAL);
                rowLayout.setPadding(0, 16, 0, 16);

                TextView itemTextView =
                        new TextView(requireContext());

                itemTextView.setText(itemName);
                itemTextView.setTextSize(16);

                itemTextView.setLayoutParams(
                        new LinearLayout.LayoutParams(
                                0,
                                LinearLayout.LayoutParams.WRAP_CONTENT,
                                1
                        )
                );

                TextView quantityTextView =
                        new TextView(requireContext());

                quantityTextView.setText(String.valueOf(quantity));
                quantityTextView.setTextSize(16);
                quantityTextView.setGravity(android.view.Gravity.CENTER);

                int quantityWidth =
                        (int) (80 * getResources()
                                .getDisplayMetrics().density);

                quantityTextView.setLayoutParams(
                        new LinearLayout.LayoutParams(
                                quantityWidth,
                                LinearLayout.LayoutParams.WRAP_CONTENT
                        )
                );

                Button deleteButton =
                        new Button(requireContext());

                deleteButton.setText(R.string.delete_item);

                int deleteWidth =
                        (int) (80 * getResources()
                                .getDisplayMetrics().density);

                deleteButton.setLayoutParams(
                        new LinearLayout.LayoutParams(
                                deleteWidth,
                                LinearLayout.LayoutParams.WRAP_CONTENT
                        )
                );

                deleteButton.setOnClickListener(v -> {
                    if (databaseHelper.deleteInventoryItem(itemId)) {
                        inventoryContainer.removeView(rowLayout);
                        updateEmptyInventoryMessage(inventoryContainer, textEmptyInventory);

                        Toast.makeText(
                                requireContext(),
                                "Item deleted",
                                Toast.LENGTH_SHORT
                        ).show();
                    }
                });

                rowLayout.addView(itemTextView);
                rowLayout.addView(quantityTextView);
                rowLayout.addView(createItemActions(
                        databaseHelper, itemId, itemTextView, quantityTextView,
                        deleteButton));

                inventoryContainer.addView(rowLayout);
            }
        }

        cursor.close();
        updateEmptyInventoryMessage(inventoryContainer, textEmptyInventory);

        // Add a new inventory item.
        addItemButton.setOnClickListener(v -> {
            // Recheck on submission too; never parse invalid input or write it to SQLite.
            if (!validateAddItemInputs(itemNameEditText, quantityEditText, true)) {
                addItemButton.setEnabled(false);
                return;
            }
            String itemName = itemNameEditText.getText().toString().trim();
            int quantity = Integer.parseInt(quantityEditText.getText().toString().trim());

            long newItemId = databaseHelper.addInventoryItem(itemName, quantity);

            if (newItemId != -1) {
                if (quantity <= LOW_STOCK_THRESHOLD) {
                    sendLowInventorySms(itemName);
                }

                Toast.makeText(
                        requireContext(),
                        "Item added successfully",
                        Toast.LENGTH_SHORT
                ).show();

                // Clear the input boxes.
                itemNameEditText.setText("");
                quantityEditText.setText("");
                // Clearing text triggers the watcher; leave the reset form free of errors.
                itemNameEditText.setError(null);
                quantityEditText.setError(null);

                // Hide "No inventory items yet".
                textEmptyInventory.setVisibility(View.GONE);

                // Create a new row immediately.
                LinearLayout rowLayout =
                        new LinearLayout(requireContext());

                rowLayout.setOrientation(LinearLayout.HORIZONTAL);
                rowLayout.setPadding(0, 16, 0, 16);

                TextView itemTextView =
                        new TextView(requireContext());

                itemTextView.setText(itemName);
                itemTextView.setTextSize(16);

                itemTextView.setLayoutParams(
                        new LinearLayout.LayoutParams(
                                0,
                                LinearLayout.LayoutParams.WRAP_CONTENT,
                                1
                        )
                );

                TextView quantityTextView =
                        new TextView(requireContext());

                quantityTextView.setText(String.valueOf(quantity));
                quantityTextView.setTextSize(16);
                quantityTextView.setGravity(android.view.Gravity.CENTER);

                int quantityWidth =
                        (int) (80 * getResources()
                                .getDisplayMetrics().density);

                quantityTextView.setLayoutParams(
                        new LinearLayout.LayoutParams(
                                quantityWidth,
                                LinearLayout.LayoutParams.WRAP_CONTENT
                        )
                );

                Button deleteButton =
                        new Button(requireContext());

                deleteButton.setText(R.string.delete_item);

                int deleteWidth =
                        (int) (80 * getResources()
                                .getDisplayMetrics().density);

                deleteButton.setLayoutParams(
                        new LinearLayout.LayoutParams(
                                deleteWidth,
                                LinearLayout.LayoutParams.WRAP_CONTENT
                        )
                );

                deleteButton.setOnClickListener(deleteView -> {
                    if (databaseHelper.deleteInventoryItem((int) newItemId)) {
                        inventoryContainer.removeView(rowLayout);
                        updateEmptyInventoryMessage(inventoryContainer, textEmptyInventory);

                        Toast.makeText(
                                requireContext(),
                                "Item deleted",
                                Toast.LENGTH_SHORT
                        ).show();
                    }
                });

                rowLayout.addView(itemTextView);
                rowLayout.addView(quantityTextView);
                rowLayout.addView(createItemActions(
                        databaseHelper, (int) newItemId, itemTextView, quantityTextView,
                        deleteButton));

                inventoryContainer.addView(rowLayout);

            } else {

                Toast.makeText(
                        requireContext(),
                        "Unable to add item",
                        Toast.LENGTH_SHORT
                ).show();
            }
        });

    }

    // The placeholder is a child too, so look for actual item rows rather than count views.
    private void updateEmptyInventoryMessage(LinearLayout inventoryContainer,
                                             TextView textEmptyInventory) {
        boolean hasItems = false;
        for (int index = 0; index < inventoryContainer.getChildCount(); index++) {
            if (inventoryContainer.getChildAt(index) != textEmptyInventory) {
                hasItems = true;
                break;
            }
        }
        textEmptyInventory.setVisibility(hasItems ? View.GONE : View.VISIBLE);
    }

    // Require an item name and a quantity within the supported whole-number range.
    private boolean validateAddItemInputs(EditText nameInput, EditText quantityInput,
                                          boolean showErrors) {
        boolean validName = !nameInput.getText().toString().trim().isEmpty();
        boolean validQuantity = isValidAddQuantity(quantityInput.getText().toString());
        if (showErrors) {
            nameInput.setError(validName ? null : "Enter an item name");
            quantityInput.setError(validQuantity ? null
                    : "Enter a whole number from 0 to 2147483647");
        }
        return validName && validQuantity;
    }

    private static boolean isValidAddQuantity(String input) {
        String quantityText = input.trim();
        // Digits only: reject signs, fractions, and nonnumeric pasted input.
        if (!quantityText.matches("[0-9]+")) {
            return false;
        }
        try {
            return Integer.parseInt(quantityText) >= 0;
        } catch (NumberFormatException exception) {
            // A long string of digits can still be too large for an int.
            return false;
        }
    }

    // Keep Edit and Delete in the existing action column without narrowing the name.
    private LinearLayout createItemActions(DatabaseHelper databaseHelper, int itemId,
                                           TextView itemTextView, TextView quantityTextView,
                                           Button deleteButton) {
        LinearLayout actions = new LinearLayout(requireContext());
        actions.setOrientation(LinearLayout.VERTICAL);
        actions.setLayoutParams(new LinearLayout.LayoutParams(
                deleteButton.getLayoutParams().width,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        Button editButton = new Button(requireContext());
        editButton.setText(R.string.edit_item_button);
        editButton.setContentDescription("Edit " + itemTextView.getText());
        editButton.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));
        editButton.setOnClickListener(v -> showEditItemDialog(
                databaseHelper, itemId, itemTextView, quantityTextView, editButton));

        actions.addView(editButton);
        actions.addView(deleteButton);
        return actions;
    }

    private void showEditItemDialog(DatabaseHelper databaseHelper, int itemId,
                                    TextView itemTextView, TextView quantityTextView,
                                    Button editButton) {
        LinearLayout fields = new LinearLayout(requireContext());
        fields.setOrientation(LinearLayout.VERTICAL);
        int padding = (int) (24 * getResources().getDisplayMetrics().density);
        fields.setPadding(padding, 0, padding, 0);

        TextView nameLabel = new TextView(requireContext());
        nameLabel.setText(R.string.edit_item_name_label);
        EditText nameInput = new EditText(requireContext());
        nameInput.setId(View.generateViewId());
        nameLabel.setLabelFor(nameInput.getId());
        nameInput.setInputType(InputType.TYPE_CLASS_TEXT);
        nameInput.setSingleLine(true);
        nameInput.setText(itemTextView.getText());

        TextView quantityLabel = new TextView(requireContext());
        quantityLabel.setText(R.string.edit_item_quantity_label);
        EditText quantityInput = new EditText(requireContext());
        quantityInput.setId(View.generateViewId());
        quantityLabel.setLabelFor(quantityInput.getId());
        quantityInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        quantityInput.setSingleLine(true);
        quantityInput.setText(quantityTextView.getText());

        fields.addView(nameLabel);
        fields.addView(nameInput);
        fields.addView(quantityLabel);
        fields.addView(quantityInput);

        AlertDialog dialog = new AlertDialog.Builder(requireContext())
                .setTitle("Edit inventory item")
                .setView(fields)
                .setPositiveButton("Save", null)
                .setNegativeButton("Cancel", null)
                .create();

        dialog.setOnShowListener(ignored -> {
            Button saveButton = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            TextWatcher validationWatcher = new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence text, int start,
                                              int count, int after) { }

                @Override
                public void onTextChanged(CharSequence text, int start,
                                          int before, int count) { }

                @Override
                public void afterTextChanged(Editable text) {
                    saveButton.setEnabled(validateEditInputs(nameInput, quantityInput));
                }
            };
            nameInput.addTextChangedListener(validationWatcher);
            quantityInput.addTextChangedListener(validationWatcher);
            saveButton.setEnabled(validateEditInputs(nameInput, quantityInput));

            // Install the listener after showing so a failed save keeps the dialog open.
            saveButton.setOnClickListener(v -> {
                if (!validateEditInputs(nameInput, quantityInput)) {
                    return;
                }
                String updatedName = nameInput.getText().toString().trim();
                int updatedQuantity = Integer.parseInt(
                        quantityInput.getText().toString().trim());

                if (databaseHelper.updateInventoryItem(itemId, updatedName, updatedQuantity)) {
                    int previousQuantity = Integer.parseInt(quantityTextView.getText().toString());
                    // Refresh only after SQLite confirms the update.
                    itemTextView.setText(updatedName);
                    quantityTextView.setText(String.valueOf(updatedQuantity));
                    editButton.setContentDescription("Edit " + updatedName);
                    Toast.makeText(requireContext(), "Item updated", Toast.LENGTH_SHORT).show();
                    dialog.dismiss();
                    if (updatedQuantity < previousQuantity
                            && updatedQuantity <= LOW_STOCK_THRESHOLD) {
                        sendLowInventorySms(updatedName);
                    }
                } else {
                    Toast.makeText(requireContext(), "Unable to update item",
                            Toast.LENGTH_SHORT).show();
                }
            });
        });
        dialog.show();
    }

    // Validate input and reject quantities outside the supported range.
    private boolean validateEditInputs(EditText nameInput, EditText quantityInput) {
        boolean validName = !nameInput.getText().toString().trim().isEmpty();
        nameInput.setError(validName ? null : "Enter an item name");

        boolean validQuantity;
        try {
            validQuantity = Integer.parseInt(
                    quantityInput.getText().toString().trim()) >= 0;
        } catch (NumberFormatException exception) {
            validQuantity = false;
        }
        quantityInput.setError(validQuantity ? null
                : "Enter a whole number from 0 to 2147483647");
        return validName && validQuantity;
    }

    // Store preferences separately from inventory; no database schema change is needed.
    private SharedPreferences getSmsPreferences() {
        return requireContext().getSharedPreferences(SMS_PREFERENCES, Context.MODE_PRIVATE);
    }

    private boolean hasSmsPermission() {
        return ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    @SuppressWarnings("deprecation")
    private boolean supportsSms() {
        if (requireContext().getPackageManager()
                .hasSystemFeature(PackageManager.FEATURE_TELEPHONY_MESSAGING)) {
            return true;
        }

        // Some emulators omit the feature flag; check the phone service too.
        android.telephony.TelephonyManager telephonyManager = requireContext()
                .getSystemService(android.telephony.TelephonyManager.class);

        if (telephonyManager == null) {
            return false;
        }

        if (android.os.Build.VERSION.SDK_INT >= 35) {
            return telephonyManager.isDeviceSmsCapable();
        }

        return telephonyManager.isSmsCapable();
    }

    // Accept a basic international or local number; this does not verify delivery.
    private String normalizeSmsPhone(String phone) {
        return phone.replaceAll("[\\s().-]", "");
    }

    private boolean isValidSmsPhone(String phone) {
        return phone.matches("\\+?[0-9]{3,15}");
    }

    private void showSmsSettingsDialog() {
        SharedPreferences preferences = getSmsPreferences();
        LinearLayout fields = new LinearLayout(requireContext());
        fields.setOrientation(LinearLayout.VERTICAL);
        int padding = (int) (24 * getResources().getDisplayMetrics().density);
        fields.setPadding(padding, 0, padding, 0);

        TextView explanation = new TextView(requireContext());
        explanation.setText(R.string.sms_settings_explanation);
        fields.addView(explanation);

        CheckBox enabledInput = new CheckBox(requireContext());
        enabledInput.setText(R.string.sms_enable_label);
        enabledInput.setChecked(preferences.getBoolean(SMS_ENABLED, false));
        enabledInput.setEnabled(supportsSms());
        fields.addView(enabledInput);

        TextView phoneLabel = new TextView(requireContext());
        phoneLabel.setText(R.string.sms_phone_label);
        EditText phoneInput = new EditText(requireContext());
        phoneInput.setId(View.generateViewId());
        phoneLabel.setLabelFor(phoneInput.getId());
        phoneInput.setInputType(InputType.TYPE_CLASS_PHONE);
        phoneInput.setSingleLine(true);
        phoneInput.setText(preferences.getString(SMS_PHONE, ""));
        fields.addView(phoneLabel);
        fields.addView(phoneInput);

        TextView permissionStatus = new TextView(requireContext());
        permissionStatus.setText(!supportsSms() ? R.string.sms_not_supported
                : hasSmsPermission() ? R.string.sms_status_allowed : R.string.sms_status_denied);
        fields.addView(permissionStatus);

        AlertDialog dialog = new AlertDialog.Builder(requireContext())
                .setTitle(R.string.sms_settings_title)
                .setView(fields)
                .setPositiveButton(R.string.sms_save, null)
                .setNegativeButton(android.R.string.cancel, null)
                .setNeutralButton(R.string.sms_app_permissions, (ignored, which) -> {
                    // Android settings also handles permission denials that cannot be re-prompted.
                    Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.parse("package:" + requireContext().getPackageName()));
                    startActivity(intent);
                })
                .create();
        dialog.setOnShowListener(ignored -> {
            Button saveButton = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            Runnable validate = () -> {
                boolean needsPhone = enabledInput.isChecked();
                boolean validPhone = isValidSmsPhone(normalizeSmsPhone(
                        phoneInput.getText().toString()));
                phoneInput.setEnabled(needsPhone);
                phoneInput.setError(needsPhone && !validPhone
                        ? getString(R.string.sms_phone_error) : null);
                saveButton.setEnabled(!needsPhone || validPhone);
            };
            phoneInput.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence text, int start, int count, int after) { }
                @Override
                public void onTextChanged(CharSequence text, int start, int before, int count) { }
                @Override
                public void afterTextChanged(Editable text) {
                    validate.run();
                }
            });
            enabledInput.setOnCheckedChangeListener((button, checked) -> validate.run());
            validate.run();
            saveButton.setOnClickListener(v -> {
                String phone = normalizeSmsPhone(phoneInput.getText().toString());
                boolean enabled = enabledInput.isChecked() && supportsSms();
                if (enabled && !isValidSmsPhone(phone)) {
                    return;
                }
                preferences.edit().putBoolean(SMS_ENABLED, enabled)
                        .putString(SMS_PHONE, phone).apply();
                dialog.dismiss();
                if (enabled && !hasSmsPermission()) {
                    smsPermissionLauncher.launch(Manifest.permission.SEND_SMS);
                } else {
                    Toast.makeText(requireContext(), R.string.sms_settings_saved,
                            Toast.LENGTH_SHORT).show();
                }
            });
        });
        dialog.show();
    }

    private void sendLowInventorySms(String itemName) {
        SharedPreferences preferences = getSmsPreferences();
        if (!preferences.getBoolean(SMS_ENABLED, false) || !hasSmsPermission()
                || !supportsSms()) {
            Log.i("InventorySms", "Alert skipped: disabled, permission denied, or SMS unavailable.");
            return;
        }
        String phone = preferences.getString(SMS_PHONE, "");
        if (!isValidSmsPhone(phone)) {
            Log.w("InventorySms", "Alert skipped: invalid destination.");
            return;
        }

        SmsSendTracker tracker = null;
        // Saving inventory must remain successful even if SMS fails.
        try {
            SmsManager smsManager = requireContext().getSystemService(SmsManager.class);
            if (smsManager == null) {
                Log.w("InventorySms", "SMS service is unavailable.");
                Toast.makeText(requireContext(), R.string.sms_unavailable, Toast.LENGTH_LONG).show();
                return;
            }
            String message = getString(R.string.sms_low_inventory_message, itemName);
            ArrayList<String> parts = smsManager.divideMessage(message);
            tracker = new SmsSendTracker(requireContext(), parts.size());
            ArrayList<PendingIntent> sentIntents = tracker.start();

            if (parts.size() > 1) {
                smsManager.sendMultipartTextMessage(phone, null, parts, sentIntents, null);
            } else {
                smsManager.sendTextMessage(phone, null, message, sentIntents.get(0), null);
            }
            Log.i("InventorySms", "SMS requested; waiting for Android's send result.");
        } catch (SecurityException | IllegalArgumentException | IllegalStateException
                 | UnsupportedOperationException exception) {
            if (tracker != null) {
                tracker.close();
            }
            Log.e("InventorySms", "SMS request failed; inventory remains saved.", exception);
            Toast.makeText(requireContext(), R.string.sms_unavailable, Toast.LENGTH_LONG).show();
        }
    }

    // A callback is like a receipt: Android reports the outcome after the send call returns.
    // Application context avoids keeping a Fragment or Activity alive while waiting.
    private static final class SmsSendTracker extends BroadcastReceiver {
        private static final String TAG = "InventorySms";
        private static final String PART_INDEX = "part_index";
        private final Context context;
        private final String action;
        private final boolean[] completedParts;
        private final ArrayList<PendingIntent> pendingIntents = new ArrayList<>();
        private final Handler handler = new Handler(Looper.getMainLooper());
        private boolean registered;
        private int completedCount;
        private final Runnable timeout = () -> finish(
                "No SMS send result within 60 seconds; outcome unknown. Inventory remains saved.");

        SmsSendTracker(Context context, int partCount) {
            this.context = context.getApplicationContext();
            this.action = this.context.getPackageName() + ".SMS_SENT." + UUID.randomUUID();
            this.completedParts = new boolean[partCount];
        }

        ArrayList<PendingIntent> start() {
            // This PendingIntent sends with our app's identity; the receiver is private.
            ContextCompat.registerReceiver(context, this, new IntentFilter(action),
                    ContextCompat.RECEIVER_NOT_EXPORTED);
            registered = true;
            handler.postDelayed(timeout, 60_000);
            for (int index = 0; index < completedParts.length; index++) {
                Intent intent = new Intent(action).setPackage(context.getPackageName())
                        .putExtra(PART_INDEX, index);
                pendingIntents.add(PendingIntent.getBroadcast(context, index, intent,
                        PendingIntent.FLAG_ONE_SHOT | PendingIntent.FLAG_IMMUTABLE));
            }
            return pendingIntents;
        }

        @Override
        public void onReceive(Context receivedContext, Intent intent) {
            if (!registered || !action.equals(intent.getAction())) {
                return;
            }
            int index = intent.getIntExtra(PART_INDEX, -1);
            if (index < 0 || index >= completedParts.length || completedParts[index]) {
                return;
            }
            int result = getResultCode();
            Log.i(TAG, "SMS part " + (index + 1) + "/" + completedParts.length
                    + " send result code: " + result);
            if (result != Activity.RESULT_OK) {
                finish("SMS sending failed: " + describeFailure(result)
                        + " (code " + result + "). Inventory remains saved.");
                return;
            }
            completedParts[index] = true;
            completedCount++;
            if (completedCount == completedParts.length) {
                finish("Android reports SMS sent. Recipient delivery is not confirmed.");
            }
        }

        private static String describeFailure(int code) {
            switch (code) {
                case SmsManager.RESULT_ERROR_RADIO_OFF:
                    return "cellular radio is off";
                case SmsManager.RESULT_ERROR_NO_SERVICE:
                    return "no cellular service";
                case SmsManager.RESULT_ERROR_GENERIC_FAILURE:
                    return "generic failure; check emulator modem or default SMS SIM";
                case SmsManager.RESULT_ERROR_LIMIT_EXCEEDED:
                    return "SMS sending limit exceeded";
                case SmsManager.RESULT_ERROR_NULL_PDU:
                    return "message encoding failed";
                case SmsManager.RESULT_ERROR_SHORT_CODE_NOT_ALLOWED:
                case SmsManager.RESULT_ERROR_SHORT_CODE_NEVER_ALLOWED:
                    return "short-number sending was blocked";
                default:
                    return "Android returned an error";
            }
        }

        private void finish(String status) {
            Log.i(TAG, status);
            Toast.makeText(context, status, Toast.LENGTH_LONG).show();
            close();
        }

        void close() {
            handler.removeCallbacks(timeout);
            if (registered) {
                context.unregisterReceiver(this);
                registered = false;
            }
            for (PendingIntent pendingIntent : pendingIntents) {
                pendingIntent.cancel();
            }
        }
    }
}
