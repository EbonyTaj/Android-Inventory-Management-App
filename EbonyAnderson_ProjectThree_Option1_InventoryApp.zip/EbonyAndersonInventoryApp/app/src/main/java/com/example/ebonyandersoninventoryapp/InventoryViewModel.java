package com.example.ebonyandersoninventoryapp;

import androidx.lifecycle.ViewModel;

public class InventoryViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}