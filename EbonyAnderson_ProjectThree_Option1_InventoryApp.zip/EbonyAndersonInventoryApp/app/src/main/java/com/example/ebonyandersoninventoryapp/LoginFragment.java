package com.example.ebonyandersoninventoryapp;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginFragment extends Fragment {
    private DatabaseHelper databaseHelper;

    public static LoginFragment newInstance() {
        return new LoginFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_login, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view,
                              @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        EditText usernameEditText =
                view.findViewById(R.id.editUsername);

        EditText passwordEditText =
                view.findViewById(R.id.editPassword);

        Button loginButton =
                view.findViewById(R.id.buttonLogin);

        Button createAccountButton =
                view.findViewById(R.id.buttonCreateAccount);

        databaseHelper = new DatabaseHelper(requireContext());

        loginButton.setOnClickListener(v -> {
            String username =
                    usernameEditText.getText().toString().trim();

            String password =
                    passwordEditText.getText().toString();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(
                        requireContext(),
                        "Please enter a username and password",
                        Toast.LENGTH_SHORT
                ).show();
                return;
            }

            if (databaseHelper.checkUser(username, password)) {
                Toast.makeText(
                        requireContext(),
                        "Login successful",
                        Toast.LENGTH_SHORT
                ).show();

                requireActivity()
                        .getSupportFragmentManager()
                        .beginTransaction()
                        .replace(
                                R.id.fragmentContainer,
                                InventoryFragment.newInstance()
                        )
                        .commit();

            } else {
                Toast.makeText(
                        requireContext(),
                        "Invalid username or password",
                        Toast.LENGTH_SHORT
                ).show();
            }
        });

        createAccountButton.setOnClickListener(v -> {
            String username =
                    usernameEditText.getText().toString().trim();

            String password =
                    passwordEditText.getText().toString();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(
                        requireContext(),
                        "Please enter a username and password",
                        Toast.LENGTH_SHORT
                ).show();
                return;
            }

            if (databaseHelper.addUser(username, password)) {
                Toast.makeText(
                        requireContext(),
                        "Account created successfully",
                        Toast.LENGTH_SHORT
                ).show();

                requireActivity()
                        .getSupportFragmentManager()
                        .beginTransaction()
                        .replace(
                                R.id.fragmentContainer,
                                InventoryFragment.newInstance()
                        )
                        .commit();

            } else {
                Toast.makeText(
                        requireContext(),
                        "Username already exists",
                        Toast.LENGTH_SHORT
                ).show();
            }
        });
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        if (databaseHelper != null) {
            databaseHelper.close();
        }
    }
}